GM.Name = "Black-Mesa:RP"
GM.Version = "1.0"
GM.Author = "By FPtje Falco et al, Modified by ArabianLambdaTB."
GM.Email = "N/A"
GM.Website = "N/A"

function GM:Initialize()
	-- Do stuff
end