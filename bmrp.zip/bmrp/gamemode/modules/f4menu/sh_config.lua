/*---------------------------------------------------------------------------
	
	Creator: TheCodingBeast - TheCodingBeast.com
	This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. 
	To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
	
---------------------------------------------------------------------------*/

-- Variables
TCB_Settings = {}

-- Settings
TCB_Settings.ActivationKey1 = "ShowSpare2"		// F1 (ShowHelp), 	F2 (ShowTeam), 	F3 (ShowSpare1), 	F4 (ShowSpare2)
TCB_Settings.ActivationKey2	= KEY_F4			// F1 (KEY_F1), 	F2 (KEY_F2), 	F3 (KEY_F3), 		F4 (KEY_F4)

TCB_Settings.CheckVersion	= true

TCB_Settings.HideWrongJob	= true

TCB_Settings.TitleOne		= "Black Mesa Facility"
TCB_Settings.TitleTwo		= "Menu"

TCB_Settings.PrimaryColor	= Color( 52, 152, 219, 255 )
TCB_Settings.SecondaryColor	= Color( 41, 128, 185, 255 )

-- Buttons
TCB_Settings.SidebarButtons = {
	
	{ text = "Commands", 	panel = "tcb_panel_commands", 	info = true, 	func = 6			},

	{ text = "Jobs", 		panel = "tcb_panel_jobs",		info = true,	func = "jobs"  		},
	{ text = "Entities",	panel = "tcb_panel_entities",	info = true,	func = "entities"	},
	{ text = "Weapons",		panel = "tcb_panel_guns",		info = true,	func = "weapons"	},
	{ text = "Shipments",	panel = "tcb_panel_shipments",	info = true,	func = "shipments" 	},
	{ text = "Ammo",		panel = "tcb_panel_ammo",		info = true,	func = "ammo" 		},
	{ text = "Vehicles",	panel = "tcb_panel_vehicles",	info = true,	func = "vehicles"	},

}

-- Version (Don't Change)
TCB_Settings.Version 		= "1.8"